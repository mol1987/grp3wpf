﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaPalatsetWpf.ViewModel
{
    public class CashierViewModel : BaseViewModel
    {
    }
}

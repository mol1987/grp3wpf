﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Dynamic;

namespace Library
{
    public static class LocalDataStorage
    {
        public static string WorkingPath { get; set; } = Directory.GetParent(System.Environment.CurrentDirectory).Parent.Parent.FullName;
        public static string DataFolder { get; set; } = "/Assets/Data";
        private static List<CSVFile> CSVFiles = new List<CSVFile>();
        private class CSVFile
        {
            public string Name;
            public string FileName;
            public ExpandoObject Data;
        };

        static LocalDataStorage()
        {
            
        }
       
        private static void FindFolders()
        {
            string fullPath = Path.Join(WorkingPath.AsSpan(), DataFolder.AsSpan());
            string[] Files = Directory.GetFiles(fullPath, "*csv");
        }
        public static void New() { }
        public static void Add() { }
        public static void Load() { }
        public static void Update() { }
    }
}

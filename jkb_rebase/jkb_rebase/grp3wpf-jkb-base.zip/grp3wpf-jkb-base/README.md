# grp3wpf
wpf project for 'pizza palatset'
